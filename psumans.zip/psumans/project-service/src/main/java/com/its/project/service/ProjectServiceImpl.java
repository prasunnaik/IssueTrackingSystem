package com.its.project.service;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.its.project.client.IssueClient;
import com.its.project.exception.ProjectNotFoundException;
import com.its.project.model.Project;
import com.its.project.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;
    private final IssueClient issueClient;

    public ProjectServiceImpl(
            ProjectRepository projectRepository,
            IssueClient issueClient) {

        this.projectRepository = projectRepository;
        this.issueClient = issueClient;
    }

    @Override
    public Project createProject(Project project) {
        return projectRepository.save(project);
    }

    @Override
    public List<Project> getAllProjects() {
        return projectRepository.findAll();
    }

    @Override
    public Project getProjectById(Long projectId) {

        return projectRepository.findById(projectId)
                .orElseThrow(() ->
                    new ProjectNotFoundException(
                        "Project not found with id: " + projectId
                    )
                );
    }

    @Override
    public Project updateProject(Long projectId, Project project) {

        Project existingProject = projectRepository.findById(projectId)
                .orElseThrow(() ->
                    new ProjectNotFoundException(
                        "Project not found with id: " + projectId
                    )
                );

        existingProject.setProjectName(project.getProjectName());
        existingProject.setProductOwnerId(project.getProductOwnerId());
        existingProject.setStartDate(project.getStartDate());
        existingProject.setEndDate(project.getEndDate());

        return projectRepository.save(existingProject);
    }

    @Override
    public void deleteProject(Long projectId) {

        Project existingProject = projectRepository.findById(projectId)
                .orElseThrow(() ->
                    new ProjectNotFoundException(
                        "Project not found with id: " + projectId
                    )
                );

        projectRepository.delete(existingProject);
    }

    @Override
    public List<Project> getProjectsByOwner(Long ownerId) {
        return projectRepository.findByProductOwnerId(ownerId);
    }

    // Inter-service communication using project ID
    @Override
    public List<Map<String, Object>> getIssuesByProjectId(Long projectId) {

        // Verify project exists first
        getProjectById(projectId);

        return issueClient.getIssuesByProject(projectId);
    }

    // Inter-service communication using project name
    @Override
    public List<Map<String, Object>> getIssuesByProjectName(
            String projectName) {

        Project project = projectRepository.findByProjectName(projectName);

        if (project == null) {
            throw new ProjectNotFoundException(
                "Project not found with name: " + projectName
            );
        }

        return issueClient.getIssuesByProject(project.getId());
    }
}