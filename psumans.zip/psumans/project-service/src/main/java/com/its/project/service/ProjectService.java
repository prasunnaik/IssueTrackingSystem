package com.its.project.service;

import java.util.List;
import java.util.Map;

import com.its.project.model.Project;

public interface ProjectService {

    Project createProject(Project project);

    List<Project> getAllProjects();

    Project getProjectById(Long projectId);

    Project updateProject(Long projectId, Project project);

    void deleteProject(Long projectId);

    List<Project> getProjectsByOwner(Long ownerId);

    List<Map<String, Object>> getIssuesByProjectId(Long projectId);

    List<Map<String, Object>> getIssuesByProjectName(String projectName);
}