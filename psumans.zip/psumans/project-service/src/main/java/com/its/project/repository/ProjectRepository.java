package com.its.project.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.its.project.model.Project;

public interface ProjectRepository extends JpaRepository<Project, Long> {

    List<Project> findByProductOwnerId(Long ownerId);

    Project findByProjectName(String projectName);
}