package com.its.project.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.its.project.model.Project;
import com.its.project.service.ProjectService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/projects")
public class ProjectController {

    private final ProjectService projectService;

    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @GetMapping
    public ResponseEntity<List<Project>> getAllProjects() {

        return new ResponseEntity<>(
                projectService.getAllProjects(),
                HttpStatus.OK
        );
    }

    @PostMapping
    public ResponseEntity<Project> createProject(
            @Valid @RequestBody Project project) {

        return new ResponseEntity<>(
                projectService.createProject(project),
                HttpStatus.CREATED
        );
    }

    @GetMapping("/{projectId}")
    public ResponseEntity<Project> getProjectById(
            @PathVariable Long projectId) {

        return new ResponseEntity<>(
                projectService.getProjectById(projectId),
                HttpStatus.OK
        );
    }

    @PutMapping("/{projectId}")
    public ResponseEntity<Project> updateProject(
            @PathVariable Long projectId,
            @Valid @RequestBody Project project) {

        return new ResponseEntity<>(
                projectService.updateProject(projectId, project),
                HttpStatus.OK
        );
    }

    @DeleteMapping("/{projectId}")
    public ResponseEntity<Void> deleteProject(
            @PathVariable Long projectId) {

        projectService.deleteProject(projectId);

        return new ResponseEntity<>(
                HttpStatus.NO_CONTENT
        );
    }

    @GetMapping("/owner/{ownerId}")
    public ResponseEntity<List<Project>> getProjectsByOwner(
            @PathVariable Long ownerId) {

        return new ResponseEntity<>(
                projectService.getProjectsByOwner(ownerId),
                HttpStatus.OK
        );
    }

    // Inter-service communication by project ID
    @GetMapping("/{projectId}/issues")
    public ResponseEntity<List<Map<String, Object>>> getIssuesByProjectId(
            @PathVariable Long projectId) {

        return new ResponseEntity<>(
                projectService.getIssuesByProjectId(projectId),
                HttpStatus.OK
        );
    }

    // Inter-service communication by project name
    @GetMapping("/projectName/{projectName}/issues")
    public ResponseEntity<List<Map<String, Object>>> getIssuesByProjectName(
            @PathVariable String projectName) {

        return new ResponseEntity<>(
                projectService.getIssuesByProjectName(projectName),
                HttpStatus.OK
        );
    }
}