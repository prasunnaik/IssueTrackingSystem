package com.its.issue.service;

import java.util.List;

import com.its.issue.model.Issue;

public interface IssueService {

    Issue createIssue(Issue issue);

    List<Issue> getAllIssues();

    Issue getIssueById(Long issueId);

    Issue updateIssue(Long issueId, Issue issue);

    void deleteIssue(Long issueId);

    List<Issue> getIssuesByProject(Long projectId);

    List<Issue> getIssuesByOwner(Long ownerId);

    List<Issue> getIssuesByAssignee(Long assigneeId);
}