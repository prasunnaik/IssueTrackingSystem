package com.its.issue.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.its.issue.model.Project;

@FeignClient(name = "project-service")
public interface ProjectClient {

    @GetMapping("/api/projects/owner/{ownerId}")
    List<Project> getProjectsByOwner(
            @PathVariable("ownerId") Long ownerId);
}