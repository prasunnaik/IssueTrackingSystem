package com.its.issue.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.its.issue.model.Issue;

public interface IssueRepository extends JpaRepository<Issue, Long> {

    List<Issue> findByProjectId(Long projectId);

    List<Issue> findByAssigneeId(Long assigneeId);
}